可以从：

https://github.com/pxb1988/dex2jar/releases

下载最新版本，比如：

https://github.com/pxb1988/dex2jar/files/1867564/dex-tools-2.1-SNAPSHOT.zip
